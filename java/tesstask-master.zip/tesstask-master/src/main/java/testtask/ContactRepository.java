package testtask;

import javax.transaction.Transactional;
import org.springframework.data.repository.CrudRepository;
import java.util.List;

@Transactional
public interface ContactRepository extends CrudRepository<Contact, Integer> {
    List<Contact> findByFullNameContaining(String fullName);
}

