package testtask;

import com.google.common.collect.Lists;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.beans.factory.annotation.Autowired;
import java.util.List;
import java.util.Map;

@Controller
public class RouteController {

    @Autowired
    private ContactRepository contactRepo;

    @RequestMapping("/")
    public String list(Model model) {
        List<Contact> contacts = Lists.newArrayList(contactRepo.findAll());
        model.addAttribute("contacts", contacts);
        return "list";
    }

    @RequestMapping(value = "/delete_contact/{id}")
    public String deleteContact(@PathVariable int id) {
        contactRepo.delete(id);
        return "redirect:/";
    }

    @RequestMapping(value = "/edit_contact/{id}", method =  RequestMethod.GET)
    public String showEditContact(@PathVariable int id, Model model) {
        Contact contact = contactRepo.findOne(id);
        model.addAttribute("contact", contact);
        return "contact_entity_form";
    }

    @RequestMapping(value = "/new_contact", method =  RequestMethod.GET)
    public String showNewContact() {
        return "contact_entity_form";
    }

    @RequestMapping(value = "/new_contact", method =  RequestMethod.POST)
    public String newContact(@RequestParam Map<String, String> params) {
        Contact contact = new Contact(params.get("name"), params.get("phone"));
        contactRepo.save(contact);
        return "redirect:/";
    }

    @RequestMapping(value = "/edit_contact/{id}", method =  RequestMethod.POST)
    public String editContact(@PathVariable int id, @RequestParam Map<String, String> params) {
        Contact contact = contactRepo.findOne(id);
        contact.setFullName(params.get("name"));
        contact.setPhoneNumber(params.get("phone"));
        contactRepo.save(contact);
        return "redirect:/";
    }

    @RequestMapping(value = "/search")
    public String searchContact(@RequestParam(value="contents", required=true) String contents, Model model) {
        List<Contact> contacts = Lists.newArrayList(contactRepo.findByFullNameContaining(contents));
        model.addAttribute("contacts", contacts);
        model.addAttribute("partial", true);
        return "list";
    }
}