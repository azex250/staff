import edu.princeton.cs.algs4.StdRandom;
import edu.princeton.cs.algs4.StdStats;


public class PercolationStats {
  private int T;
  private double xarray[];

  public PercolationStats(int N, int T) {
  	if (N <= 0 || T <= 0) {
  		throw new IllegalArgumentException("row index i out of bounds");
  	}
  	xarray = new double[T];
  	this.T = T;
  	Percolation per;
  	for (int i = 0; i < T; i++) {
		per = new Percolation(N);
  		int j = 0;
		int row = StdRandom.uniform(N);
		int column = StdRandom.uniform(N);
  		while (!per.percolates()) {
  			j++;

  			do {
				row = StdRandom.uniform(N);
				column = StdRandom.uniform(N);
  			} while(per.isOpen(row + 1, column + 1));

			per.open(row + 1, column + 1);
  		}
  		xarray[i] = ((double) j / (double) (N * N));
  		per = null;
  	}
  }    
  public double mean() {
  	return StdStats.mean(xarray);
  }                   
  public double stddev() {
  	return StdStats.stddev(xarray);
  }  
  public double confidenceLo() {
  	return mean() - (1.96 * stddev() / Math.sqrt(T));
  }     
  public double confidenceHi() {
  	return mean() + (1.96 * stddev() / Math.sqrt(T));
  }    

  public static void main(String[] args) {
  	PercolationStats per = new PercolationStats(Integer.parseInt(args[0]), Integer.parseInt(args[1]));
  	System.out.println(per.mean());
  	System.out.println(per.stddev());
  	System.out.println(per.confidenceLo());
  	System.out.println(per.confidenceHi());
  }
}