import edu.princeton.cs.algs4.WeightedQuickUnionUF;

public class Percolation {
  private WeightedQuickUnionUF qu;
  private WeightedQuickUnionUF qu2;
  private final int side;
  private int top;
  private int bottom;
  private boolean percolate;
  private boolean[] isOpen;

  public Percolation(final int gridSide) {
    if (gridSide <= 0) {
      throw new IllegalArgumentException("row index i out of bounds");
    }
    this.side = gridSide;
    this.isOpen = new boolean[gridSide * gridSide + 2];
    this.qu = new WeightedQuickUnionUF(gridSide * gridSide + 2);
    this.qu2 = new WeightedQuickUnionUF(gridSide * gridSide + 1);
    this.top = gridSide * gridSide;
    this.bottom = gridSide * gridSide +1;
    this.isOpen[top] = true;
    this.isOpen[bottom] = true;
    this.percolate = false;
  }

  public void open(final int rawRow, final int rawColumn) {
    if (rawRow <= 0 || rawRow > side || rawColumn <= 0 || rawColumn > side) {
      throw new IndexOutOfBoundsException("row index i out of bounds");
    }
    int row = rawRow - 1;
    int column = rawColumn - 1;
    int index = row + column * this.side;

    if (this.isOpen[index] == true) {
      return;
    }

    this.isOpen[index] = true;
    this.checkUnion(index, row, column + 1);
    this.checkUnion(index, row, column - 1);
    this.checkUnion(index, row + 1, column);
    this.checkUnion(index, row - 1, column);
  }

  private void checkUnion(final int index, final int row, final int column) {
    if (column == -1 || column == this.side) {
      return;
    }

    int index2;

    if (row == this.side) {
      index2 = this.bottom;
    } else if (row == -1) {
      index2 = top;
    }  else {
      index2 = row + column * this.side;
    }

    if (!isOpen[index2]) {
      return;
    }

    if (index2 != bottom && !qu2.connected(index, index2)) 
        this.qu2.union(index, index2);

    if (!qu.connected(index, index2)) {
      this.qu.union(index, index2);
    }
  }

  public boolean isOpen(final int rawRow, final int rawColumn) {
    if (rawRow <= 0 || rawRow > side || rawColumn <= 0 || rawColumn > side) {
      throw new IndexOutOfBoundsException("row index i out of bounds");
    }
    int row = rawRow - 1;
    int column = rawColumn - 1;
    return this.isOpen[row + column * this.side];
  }

  public boolean isFull(final int rawRow, final int rawColumn) {
    if (rawRow <= 0 || rawRow > side || rawColumn <= 0 || rawColumn > side) {
      throw new IndexOutOfBoundsException("row index i out of bounds");
    }
    int row = rawRow - 1;
    int column = rawColumn - 1;
    if (!isOpen[row + column * this.side]) {
      return false;
    }
    return qu2.connected(top, row + column * this.side);
  }

  public boolean percolates() {
    return qu.connected(top, bottom);
  }
}
